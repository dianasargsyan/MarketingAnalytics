from setuptools import setup

setup(
   name='A/B testing platform',
   group='1.0',
   description='Easy usage of data and research',
   author='AUA student',
   author_email='alen_adamyan@edu.aua.am',
   packages=['foo'],  #same as name
   python_requires='=3.9.12',
  # install_requires=['wheel', 'bar', 'greek'], #external packages as dependencies
)