from .layout import layout
from .tab1 import layout1
from .tab2 import layout2
from .tab3 import layout3
from .layout import var